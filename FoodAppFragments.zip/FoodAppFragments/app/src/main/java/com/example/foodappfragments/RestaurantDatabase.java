package com.example.foodappfragments;

import android.content.Context;
import android.content.res.Resources;
import java.util.ArrayList;
import java.util.List;

public class RestaurantDatabase {

    private static RestaurantDatabase sRestaurantDatabase;
    private List<Restaurant> mRestaurants;

    public static RestaurantDatabase getInstance(Context context) {
        if (sRestaurantDatabase == null) {
            sRestaurantDatabase = new RestaurantDatabase(context);
        }
        return sRestaurantDatabase;
    }

    private RestaurantDatabase(Context context) {
        mRestaurants = new ArrayList<>();
        Resources res = context.getResources();
        String[] restaurants = res.getStringArray(R.array.restaurants);
        String[] descriptions = res.getStringArray(R.array.descriptions);
        for (int i = 0; i < restaurants.length; i++) {
            mRestaurants.add(new Restaurant(i + 1, restaurants[i], descriptions[i]));
        }
    }

    public List<Restaurant> getrestaurant() {
        return mRestaurants;
    }

    public Restaurant getrestaurant(int restaurantId) {
        for (Restaurant restaurant : mRestaurants) {
            if (restaurant.getId() == restaurantId) {
                return restaurant;
            }
        }
        return null;
    }
}
